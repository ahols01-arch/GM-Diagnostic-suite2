# GM Powertrain Diagnostics — source bundle v0.3.0

Target: Android phone, 1997 GMC C1500 5.7L V8, paired Bluetooth Classic ELM327.

## Included
- Bluetooth Classic SPP connection and saved adapter selection
- Automatic reconnect setting, OBD protocol selection, refresh interval and timeout settings
- Basic/advanced ELM terminal with basic safety blocks
- Standard OBD-II stored/pending/permanent DTC reads, freeze-frame requests, readiness checks and confirmed code clearing
- Live dashboard, supported sensor requests, live RPM/coolant/throttle graph
- Session logging and Android share/export
- Vehicle profile editor
- Custom standard PID/raw command editor
- GM module support-check screen and connection troubleshooting

## Important limitations
This is not a full TIS2000/Tech 2 replacement. Generic ELM327 plus standard OBD-II cannot guarantee access to all GM Class 2 modules, ABS/SRS/body modules, enhanced transmission data, bidirectional actuator tests, security access, or programming. Sensor availability depends on ECU and adapter support. Code clearing erases diagnostic evidence and may reset emissions readiness. Do not operate the app while driving. Test on the vehicle only when safely parked.

## GitHub Actions build
Workflow: `.github/workflows/android.yml`. Java 17, Gradle 8.9. Build artifact: `gm-powertrain-diagnostics-debug-apk-v0.3.0`, containing `app-debug.apk`.

If uploading this ZIP to the repository root, keep its filename starting with `GM_Powertrain_Diagnostics_Updated` so the workflow's bundle step finds it. The bundle contains source files and the workflow, not a prebuilt APK. A successful build does not mean the code has been tested against the user's particular adapter or truck.
