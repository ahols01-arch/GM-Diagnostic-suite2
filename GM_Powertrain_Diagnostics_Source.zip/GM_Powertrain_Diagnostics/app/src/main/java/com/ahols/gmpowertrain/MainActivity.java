package com.ahols.gmpowertrain;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter btAdapter;
    private BluetoothSocket socket;
    private InputStream in;
    private OutputStream out;
    private TextView status, output;
    private final Object ioLock = new Object();
    private volatile boolean busy = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        btAdapter = BluetoothAdapter.getDefaultAdapter();
        buildUi();
        if (btAdapter == null) setStatus("This phone does not report Bluetooth support.");
        else setStatus("Not connected. Pair the ELM327 in Android Bluetooth settings first.");
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22, 24, 22, 28); root.setBackgroundColor(0xFFF3F5F7);
        TextView title = new TextView(this); title.setText("GM POWERTRAIN DIAGNOSTICS"); title.setTextSize(21); title.setTextColor(0xFF101820); title.setTypeface(null, 1); root.addView(title);
        TextView subtitle = new TextView(this); subtitle.setText("ELM327 • OBD-II starter build"); subtitle.setTextSize(14); subtitle.setTextColor(0xFF536170); root.addView(subtitle);
        status = new TextView(this); status.setTextSize(14); status.setTextColor(0xFF0D47A1); status.setPadding(0,18,0,12); root.addView(status);
        addButton(root, "Connect Bluetooth adapter", v -> chooseDevice());
        addButton(root, "Read / identify vehicle", v -> runCommand("ATI\nATDP\n0100", "Adapter and supported OBD-II PIDs"));
        addButton(root, "Read stored trouble codes", v -> readCodes("03", "Stored trouble codes"));
        addButton(root, "Read pending trouble codes", v -> readCodes("07", "Pending trouble codes"));
        addButton(root, "Read permanent trouble codes", v -> readCodes("0A", "Permanent trouble codes"));
        addButton(root, "Read live powertrain data", v -> readLiveData());
        addButton(root, "Read freeze-frame data", v -> runCommand("0200\n0202\n020C\n0205", "Freeze-frame snapshot (where supported)"));
        addButton(root, "Check readiness monitors", v -> runCommand("0101", "Emissions readiness monitors"));
        addButton(root, "Clear trouble codes", v -> confirmClear());
        TextView warning = new TextView(this); warning.setText("SAFETY / LIMITS\nClear codes only after saving them. Clearing may reset readiness monitors and erase useful freeze-frame evidence. ELM327 supports standard OBD-II; GM-enhanced controls, module programming, security access, and many bidirectional tests are not provided by this adapter. Do not use the app while driving."); warning.setTextSize(13); warning.setTextColor(0xFF7A2E00); warning.setPadding(12,14,12,14); warning.setBackgroundColor(0xFFFFF0E0); root.addView(warning);
        TextView outLabel = new TextView(this); outLabel.setText("DIAGNOSTIC OUTPUT"); outLabel.setTextColor(0xFF101820); outLabel.setTypeface(null,1); outLabel.setPadding(0,18,0,8); root.addView(outLabel);
        output = new TextView(this); output.setText("Connect an adapter, then choose a diagnostic function."); output.setTextSize(14); output.setTextColor(0xFF17212B); output.setPadding(14,14,14,14); output.setBackgroundColor(0xFFFFFFFF); output.setTextIsSelectable(true); root.addView(output);
        scroll.addView(root); setContentView(scroll);
    }

    private void addButton(LinearLayout root, String label, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(15); b.setGravity(Gravity.CENTER_VERTICAL); b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 7; root.addView(b, lp);
    }
    private void setStatus(String s) { if (status != null) status.setText(s); }
    private void showOutput(String s) { runOnUiThread(() -> output.setText(s)); }

    private boolean hasConnectPermission() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }
    private void chooseDevice() {
        if (btAdapter == null) { toast("Bluetooth is unavailable on this phone."); return; }
        if (Build.VERSION.SDK_INT >= 31 && !hasConnectPermission()) { requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 41); return; }
        if (!btAdapter.isEnabled()) { toast("Turn Bluetooth on in Android settings, then try again."); return; }
        try {
            Set<BluetoothDevice> paired = btAdapter.getBondedDevices();
            ArrayList<BluetoothDevice> devices = new ArrayList<>(paired);
            if (devices.isEmpty()) { toast("No paired devices. Pair the ELM327 in Android Bluetooth settings first."); return; }
            String[] names = new String[devices.size()];
            for (int i=0;i<devices.size();i++) names[i] = devices.get(i).getName() + "  (" + devices.get(i).getAddress() + ")";
            new AlertDialog.Builder(this).setTitle("Select paired adapter").setItems(names, (d, which) -> connect(devices.get(which))).setNegativeButton("Cancel", null).show();
        } catch (SecurityException e) { toast("Bluetooth permission is required."); }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 41 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) chooseDevice();
        else if (requestCode == 41) toast("Bluetooth permission was not granted.");
    }
    private void connect(BluetoothDevice device) {
        setStatus("Connecting to " + device.getName() + "…");
        new Thread(() -> {
            try {
                closeSocket();
                BluetoothSocket s = device.createRfcommSocketToServiceRecord(SPP_UUID);
                s.connect(); socket=s; in=s.getInputStream(); out=s.getOutputStream();
                String init = command("ATZ") + command("ATE0") + command("ATL0") + command("ATS0") + command("ATH0") + command("ATSP0");
                runOnUiThread(() -> setStatus("Connected to " + safeName(device) + " • ELM initialization sent"));
                showOutput("Adapter connected. Initialization response:\n" + init + "\nReady for OBD-II requests.");
            } catch (Exception e) { closeSocket(); runOnUiThread(() -> setStatus("Connection failed: " + e.getMessage())); }
        }).start();
    }
    private String safeName(BluetoothDevice d) { try { return d.getName(); } catch (Exception e) { return "Bluetooth adapter"; } }
    private void closeSocket() { try { if (socket != null) socket.close(); } catch(Exception ignored) {} socket=null; in=null; out=null; }

    private String command(String cmd) throws Exception {
        synchronized (ioLock) {
            if (socket == null || !socket.isConnected() || out == null || in == null) throw new Exception("Not connected. Connect your paired ELM327 first.");
            while (in.available() > 0) in.read();
            out.write((cmd + "\r").getBytes(StandardCharsets.US_ASCII)); out.flush();
            StringBuilder response = new StringBuilder(); long end = System.currentTimeMillis() + 2600;
            while (System.currentTimeMillis() < end) {
                if (in.available() > 0) {
                    int c = in.read(); if (c >= 0) { if (c == '>') break; response.append((char)c); }
                } else { if (response.length() > 0) { Thread.sleep(120); if (in.available()==0) break; } else Thread.sleep(35); }
            }
            return response.toString().replace("\r", "\n").trim();
        }
    }
    private void runCommand(String commands, String heading) {
        if (busy) { toast("A request is already running."); return; }
        busy=true; showOutput(heading + "\nWorking…");
        new Thread(() -> { StringBuilder sb=new StringBuilder(heading).append("\n\n"); try { for(String c:commands.split("\\n")) sb.append("> ").append(c).append("\n").append(command(c)).append("\n\n"); } catch(Exception e) { sb.append("ERROR: ").append(e.getMessage()); } showOutput(sb.toString()); busy=false; }).start();
    }
    private void readCodes(String mode, String heading) {
        if (busy) { toast("A request is already running."); return; }
        busy=true; showOutput(heading + "\nWorking…");
        new Thread(() -> { String result=""; try { result=command(mode); } catch(Exception e) { result="ERROR: "+e.getMessage(); }
            String parsed = decodeCodes(result, mode); showOutput(heading + "\nRaw response: " + result + "\n\n" + parsed); busy=false; }).start();
    }
    private String decodeCodes(String raw, String mode) {
        String clean=raw.toUpperCase().replaceAll("[^0-9A-F]", " ").trim();
        String[] tokens=clean.split("\\s+"); ArrayList<Integer> bytes=new ArrayList<>();
        for(String t:tokens) if(t.matches("[0-9A-F]{2}")) { try { bytes.add(Integer.parseInt(t,16)); } catch(Exception ignored) {} }
        int expected=mode.equals("03")?0x43:mode.equals("07")?0x47:0x4A; int start=bytes.indexOf(expected);
        if(start>=0) { StringBuilder b=new StringBuilder(); int found=0; for(int i=start+1;i+1<bytes.size();i+=2) { int a=bytes.get(i), c=bytes.get(i+1); if(a==0 && c==0) continue; b.append("• ").append(formatDtc(a,c)).append("\n"); found++; } if(found>0)return b.toString(); return "No codes reported in this response."; }
        if(raw.contains("NO DATA")) return "No data returned. The vehicle may not support this mode, or the adapter may not be communicating with the ECU.";
        if(raw.contains("UNABLE TO CONNECT")) return "Unable to connect to the vehicle ECU. Check ignition position, adapter compatibility, and vehicle protocol.";
        return "Could not reliably decode this adapter response. Check the raw response above; some ELM327 clones format replies differently.";
    }
    private String formatDtc(int a, int b) { char[] first={'P','C','B','U'}; int kind=(a>>6)&3; int d1=(a>>4)&3; int d2=a&15; return ""+first[kind]+d1+Integer.toHexString(d2).toUpperCase()+Integer.toHexString((b>>4)&15).toUpperCase()+Integer.toHexString(b&15).toUpperCase(); }
    private void readLiveData() {
        if (busy) { toast("A request is already running."); return; }
        busy=true; showOutput("Live data\nReading supported standard PIDs…");
        new Thread(() -> {
            StringBuilder s=new StringBuilder("LIVE POWERTRAIN DATA\n\n");
            String[][] pids={{"010C","Engine RPM"},{"0105","Coolant temperature"},{"010D","Vehicle speed"},{"0111","Throttle position"},{"0104","Calculated engine load"},{"0106","Short-term fuel trim bank 1"},{"0107","Long-term fuel trim bank 1"},{"010F","Intake air temperature"},{"010B","Intake manifold pressure"},{"010E","Ignition timing advance"}};
            try { for(String[] p:pids) { String r=command(p[0]); s.append(p[1]).append(": ").append(parsePid(p[0],r)).append("\n"); } }
            catch(Exception e) { s.append("\nERROR: ").append(e.getMessage()); }
            showOutput(s.toString()); busy=false;
        }).start();
    }
    private String parsePid(String pid, String raw) {
        String hex=raw.toUpperCase().replaceAll("[^0-9A-F]", " ").trim(); String[] t=hex.split("\\s+"); ArrayList<Integer> b=new ArrayList<>();
        for(String x:t) if(x.matches("[0-9A-F]{2}")) try { b.add(Integer.parseInt(x,16)); } catch(Exception ignored) {}
        int expected; try { expected=Integer.parseInt(pid.substring(2),16); } catch(Exception e) { return raw; }
        int idx=-1; for(int i=0;i+1<b.size();i++) if(b.get(i)==0x41 && b.get(i+1)==expected) {idx=i+2;break;}
        if(idx<0 || idx>=b.size()) return raw.contains("NO DATA")?"Not supported / no data":raw;
        int a=b.get(idx), c=idx+1<b.size()?b.get(idx+1):0;
        switch(pid) {
            case "010C": if(idx+1<b.size()) return String.format(java.util.Locale.US,"%.0f rpm",((a*256+c)/4.0)); break;
            case "0105": return (a-40)+" °C ("+String.format(java.util.Locale.US,"%.0f",(a-40)*9/5.0+32)+" °F)";
            case "010D": return a+" km/h ("+String.format(java.util.Locale.US,"%.1f",a*0.621371)+" mph)";
            case "0111": return String.format(java.util.Locale.US,"%.1f%%",a*100.0/255.0);
            case "0104": return String.format(java.util.Locale.US,"%.1f%%",a*100.0/255.0);
            case "0106": case "0107": return String.format(java.util.Locale.US,"%.1f%%",(a-128)*100.0/128.0);
            case "010F": return (a-40)+" °C ("+String.format(java.util.Locale.US,"%.0f",(a-40)*9/5.0+32)+" °F)";
            case "010B": return a+" kPa";
            case "010E": return String.format(java.util.Locale.US,"%.1f°",a/2.0-64);
        }
        return raw;
    }
    private void confirmClear() {
        new AlertDialog.Builder(this).setTitle("Clear diagnostic trouble codes?").setMessage("Save codes and freeze-frame data first. Clearing can erase diagnostic evidence and reset emissions readiness. Continue only if you intend to clear them.").setNegativeButton("Cancel",null).setPositiveButton("Clear codes",(d,w)->runCommand("04","Clear trouble codes")).show();
    }
    private void toast(String s) { runOnUiThread(() -> Toast.makeText(this,s,Toast.LENGTH_LONG).show()); }
    @Override protected void onDestroy() { closeSocket(); super.onDestroy(); }
}
